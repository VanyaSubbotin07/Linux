#include <stdio.h>
#include "sum.h"
#include "sub.h"

int main() {
	int a = 2;
	int b = 3;
	
	int c = sum(a, b);
	int d = sub(a, b);
	
	printf("c=%d, d=%d\n", c, d);
	
	return 0;
}
